package com.projetorango.Rango;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RangoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RangoApplication.class, args);
	}

}
